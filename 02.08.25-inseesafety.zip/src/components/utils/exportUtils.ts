// src/utils/exportUtils.js
//import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { formatDate } from './employeeUtils';
import './Sarabun-Regular-normal'; // เส้นทางขึ้นกับที่วางฟอนต์ เราวางไว้ที่นี่ Sarabun-Regular-normal.js
import { format, parseISO } from 'date-fns';


export const prepareExportData = (data, fields, headers = {}, format = 'generic') => {
  return data.map(item => {
    const formatted = {};

    fields.forEach(key => {
      // 🔒 Skip certificateURL except JSON
      if (key === 'certificateURL') {
        if (format === 'json') {
          formatted[headers[key] || key] = item[key] ?? '';
        }
        return;
      }

      let value = item[key];

      // 🕒 Format dates
      if (['trainingDate', 'expiryDate', 'updatedAt'].includes(key)) {
        value = formatDate(value);
      }

      // 🔗 Excel formula link if desired (you can comment this if not needed)
      if (key === 'certificateURL' && typeof value === 'string') {
        if (format === 'excel') {
          value = `=HYPERLINK("${value}", "เปิดไฟล์")`;
        }
      }

      // ❌ Remove object fields
      if (typeof value === 'object' && value !== null) {
        value = '';
      }

      formatted[headers[key] || key] = value ?? '';
    });

    return formatted;
  });
};

// ✅ Excel
export const exportToExcel = (data, filename = 'export') => {
  const worksheet = XLSX.utils.json_to_sheet(data);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Data');
  XLSX.writeFile(workbook, `${filename}_${format(new Date(), 'yyMMddHHmmss')}.xlsx`);
};

// ✅ PDF
export const exportToPDF = (data, filename = 'export', headerArray = []) => {
  const doc = new jsPDF({
    orientation: 'portrait', //landscape
    unit: 'pt',
    format: 'a4'
  });

  doc.setFont('Sarabun-Regular'); // ✅ ชื่อต้องตรงกับในฟอนต์ .js
  doc.setFontSize(10);

  // ทดสอบข้อความไทยด้านบน (optional)
  doc.text('รายงานผลการฝึกอบรม', 40, 30);

  const headers = [headerArray];
  const rows = data.map(row =>
    headerArray.map(header => {
      const value = row[header];
      return typeof value === 'string' ? value : String(value ?? '');
    })
  );

  autoTable(doc, {
    head: headers,
    body: rows,
    styles: {
      font: 'Sarabun-Regular', // ✅ ต้องตรง
      fontSize: 10,
    },
    startY: 50,
    theme: 'grid',
    headStyles: { fillColor: [22, 160, 133] }
  });

  doc.save(`${filename}.pdf`);
};

// ✅ CSV
export const exportToCSV = (data, filename = 'export') => {
  const ws = XLSX.utils.json_to_sheet(data);
  const csv = XLSX.utils.sheet_to_csv(ws);
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', `${filename}_${format(new Date(), 'yyMMddHHmmss')}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

// ✅ JSON
export const exportToJSON = (data, filename = 'export') => {
  const json = JSON.stringify(data, null, 2);
  const blob = new Blob([json], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', `${filename}_${format(new Date(), 'yyMMddHHmmss')}.json`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};