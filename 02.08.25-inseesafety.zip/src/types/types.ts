// ========================================================================
// ไฟล์: src/types/index.ts - แก้ไขและปรับปรุง Types
// กำหนด Type และ Interface ทั้งหมดที่ใช้ในโปรเจกต์
// ========================================================================
import { Timestamp } from 'firebase/firestore';

export type Role = 'superadmin' | 'admin' | 'plantAdmin' | 'guest';

//  BaseEmployeeData - เพิ่ม email field ที่จำเป็น
export interface BaseEmployeeData {
  id: string; // Firestore Document ID
  empId: string;
  email?: string; //  จำเป็นสำหรับการค้นหา
  idCard?: string; // ประจำตัวประชาชน  
  prefix?: string;  
  firstName?: string;
  lastName?: string;
  fullName?: string;
  displayName?: string; // local name  
  position?: string;
  profileImageUrl?: string | null; 
  phoneNumber?: string;
  address?: string;
  dateOfBirth?: string | Date | null;   
  startDate?: string | Date | null; 
  cardExpiryDate?: string |Date | null; 
  company?: string;
  companyId?: string;
  plantId?: string| null; 
  employeeType?: 'employee' | 'contractor' | 'transporter' | 'driver' | 'pending';    
  status: 'active' | 'inactive' | 'terminated' | 'pending' | 'blacklist';
  createdAt: Timestamp | Date | string; 
  updatedAt?: Timestamp | Date | string; 
}

//  EmployeeFormState - ปรับให้สอดคล้องกับ BaseEmployeeData
export interface EmployeeFormState extends Partial<BaseEmployeeData> {
  //email: string;
  level?: string; 
  nickname?: string;  
  department?: string;
  siteId?: string; 
  zoneId?: string;
  countryId?: string;
  startDate?: string | Date;
  lastUpdateBy?: string;
  searchKeywords?: string[];
}

// EmployeeProfile - ปรับให้ realistic มากขึ้น
export interface EmployeeProfile extends BaseEmployeeData {
  id: string; // Firestore document ID
  email: string; // ✅ ทำให้ required
  searchKeywords: string[]; // **สำคัญมาก** สำหรับการค้นหา
  createdAt: Timestamp | Date | string; // ✅ ทำให้ required
  updatedAt: Timestamp | Date | string; // ✅ ทำให้ required
  [key: string]: unknown; // ✅ เก็บไว้สำหรับ flexibility
}

export interface OptionType {
  value: string;
  label: string;
}

export interface SearchableSelectProps {
  options: OptionType[];
  value: OptionType | null; 
  onChange: (option: OptionType | null) => void; 
  placeholder?: string;
}

// TrainingRecord
export interface TrainingRecord {
  id: string; // Firestore Document ID
  empId: string;
  courseId?: string;
  courseName?: string;  
  trainingDate?: Timestamp | Date | string | null; 
  expiryDate?: Timestamp | Date | string | null; 
  status: 'lifetime' | 'expired' | 'active' | 'pending';
  files?: File[];
  evidenceText?: string;
  updatedAt?: Timestamp | Date | string; 
  updatedBy?: string;
  createdAt: Timestamp | Date | string;
  [key: string]: unknown; // ✅ เก็บไว้สำหรับ flexibility
}

export interface TrainingSummary {
  total: number;
  active: number;
  expired: number;
  uniqueCourses: string[];
}

export interface UserRole {
  uid?: string; // Firebase Auth UID
  empId: string;
  email: string;
  role: Role;
  displayName: string | null;  
  passcode?: string; // Only for internal users
  isActive: boolean;
  managedCountry?: string[];
  managedZones?: string[];
  managedSites?: string[];
  managedPlants?: string[];  
  createdAt?: Date | Timestamp; 
  updatedAt?: Date | Timestamp;
}

export interface UserPermissions {
    empId: string;
    email: string;
    role: Role;
    isActive: boolean;
    passcode?: string; // สำหรับ Internal Login
    displayName?: string;
}

//  AppUser - ปรับให้สอดคล้องกับการใช้งานจริง
export interface AppUser {
  uid: string; // Firebase Auth UID
  empId: string | null; // Employee ID 
  email: string | null;
  displayName: string | null;
  role: string | null; 
  profile: EmployeeProfile | { displayName: string | null }; 
  //managedCountry?: string | string[]; // ✅ แก้ไข: อาจจะเป็น array
  //managedZones?: string[];
  //managedSites?: string[];
  //managedPlants?: string[];  
  //empUser: string | null;
  //firebaseLinkedEmpProfile: string | null;
  loginType: 'provider' | 'firebase' |'internal' | null;
}

// AuthContextType - ปรับให้สอดคล้องกับการใช้งาน
export interface AuthContextType {
  user: AppUser | null;
  currentUser: unknown; // Firebase User object
  empUser: EmployeeProfile | null; // Employee login user
  firebaseLinkedEmpProfile: EmployeeProfile | null; // Firebase linked employee profile
  loginType: 'provider' | 'firebase' |'internal' | null; // ✅ เพิ่ม 'internal'
  currentUserClaims: unknown; // Firebase custom claims
  loading: boolean; 
  error: string | null;
  setError: (error: string | null) => void;
  signInWithGoogle: () => Promise<void>;
  signInWithEmail: (email: string, password: string) => Promise<void>;
  signInWithInternalCredentials: (empId: string, passcode: string) => Promise<void>;
  signInInternal: (empId: string, passcode: string) => Promise<void>;
  logout: () => Promise<void>;
}

// ✅ คงเดิม: LoginResult
export interface LoginResult {
  success: boolean;
  user?: AppUser;
  error?: string;
  redirecting?: boolean; // ใช้สำหรับการเปลี่ยนเส้นทางหลังจากล็อกอินสำเร็จ
  message?: string; 
}


export interface TrainingCourse {
  id: string;
  courseName: string;
  description?: string;
  duration?: number; // ชั่วโมง
  validityPeriod?: number; // จำนวนวันที่ใช้ได้
  isLifetime: boolean;
  category?: string;
}

// ✅ เพิ่ม: Helper types สำหรับ Collections
export interface Country {
  id: string;
  name: string;
  code: string;
  isActive: boolean;
}

export interface Zone {
  id: string;
  name: string;
  countryId: string;
  isActive: boolean;
}

export interface Site {
  id: string;
  name: string;
  zoneId: string;
  isActive: boolean;
}

export interface Plant {
  id: string;
  name: string;
  siteId: string;
  isActive: boolean;
}

///////////////
// ✅ คงเดิม: UI States
export interface UIState {
  isLoading: boolean;
  error: string | null;
  success: string | null;
}

export interface FilterOptions {
  company?: string;
  site?: string;
  employeeType?: string;
  status?: string;
  role?: Role;
}

export interface SearchOptions {
  query: string;
  fields: string[];
  filters: FilterOptions;
}

export interface PaginationOptions {
  page: number;
  limit: number;
  total: number;
  hasMore: boolean;
}

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
  pagination?: PaginationOptions;
}

export interface FilterState {
  search: string;
  status: 'all' | 'active' | 'expired';
  course: string;
}

export interface PaginationState {
  currentPage: number;
  totalPages: number;
  totalItems: number;
  itemsPerPage: number;
  hasNextPage: boolean;
  hasPrevPage: boolean;
}

export interface CSVImportError {
  row: number;
  field?: string;
  message: string;
  data?: Record<string, unknown>;
}

export interface CSVImportResult {
  success: number;
  failed: number;
  skipped: number;
  errors: CSVImportError[];
  duplicates: number;
}

export interface ValidationResult {
  isValid: boolean;
  errors: string[];
  warnings?: string[];
}