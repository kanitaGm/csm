// src/routes/AppRoutes.tsx
//import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from '../contexts/AuthContext';
// Layouts and Protected Routes
import ProtectedRoute from './ProtectedRoute';
import MainLayout from '../components/layout/MainLayout'; // สมมติว่ามีไฟล์นี้อยู่

// Pages
import LoginPage from '../pages/LoginPage';
import { DashboardPage } from '../pages/DashboardPage';
// import UnauthorizedPage from '../pages/UnauthorizedPage'; // ถูกรวมไปใน ProtectedRoute แล้ว
import NotFoundPage from '../pages/NotFoundPage'; // สมมติว่ามีไฟล์นี้อยู่
import ProfilePage from '../pages/employees/ProfilePage'; // สมมติว่ามีไฟล์นี้อยู่
import EmployeeListPage from '../pages/employees/EmployeeListPage'; // สมมติว่ามีไฟล์นี้อยู่
import AddEmployeePage from '../pages/employees/AddEmployeePage'; // สมมติว่ามีไฟล์นี้อยู่
import EditEmployeePage from '../pages/employees/EditEmployeePage'; // สมมติว่ามีไฟล์นี้อยู่

// Test/Util Pages
import TestPage from '../pages/test/test'; // สมมติว่ามีไฟล์นี้อยู่
import ImportCSVPage from '../components/utils/ImportCSVPage'; // สมมติว่ามีไฟล์นี้อยู่

const AppRoutes = () => {
  return (
    <AuthProvider> 
      <BrowserRouter>
        <Routes>
          {/* ========== PUBLIC ROUTES (ไม่ต้อง Login) ========== */}
          <Route path="/login" element={<LoginPage />} />
          <Route path="/profile/:empId" element={<ProfilePage />} />
          <Route path="/test" element={<TestPage />} />
          <Route path="/ImportCSVPage" element={<ImportCSVPage />} />
          
          {/* ========== PROTECTED ROUTES (ต้อง Login) ========== */}
          <Route element={<ProtectedRoute requiredRole={["admin", "superadmin"]} />}>
            <Route element={<MainLayout />}>
              {/* Route ทั้งหมดข้างในนี้จะถูกป้องกันและใช้ MainLayout */}
              <Route path="/dashboard" element={<DashboardPage />} />
              <Route path="/employees" element={<EmployeeListPage />} />
              <Route path="/employees/add" element={<AddEmployeePage />} />
              <Route path="/employees/:empId/edit" element={<EditEmployeePage />} />
            </Route>
          </Route>

          {/* Route หลัก: ถ้าเข้าเว็บครั้งแรก ให้ไปที่ /login */}
          <Route path="/" element={<Navigate to="/login" replace />} />
          
          {/* ========== 404 NOT FOUND ========== */}
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
};

export default AppRoutes;
