// Fixed useDebouncedValue Hook
// ไฟล์: src/hooks/useDebouncedValue.ts
// ================================
import { useState, useEffect} from 'react';
export const useDebouncedValue = <T>(value: T, delay: number): T => {
  const [debouncedValue, setDebouncedValue] = useState<T>(value);

  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);

    return () => {
      clearTimeout(handler);
    };
  }, [value, delay]);

  return debouncedValue;
};
