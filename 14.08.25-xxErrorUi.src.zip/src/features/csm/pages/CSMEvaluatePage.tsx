// 📁 src/features/csm/pages/CSMEvaluatePage.tsx
// Enhanced CSM Evaluation Page with Modern UX/UI
import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { useParams, useNavigate, useSearchParams } from 'react-router-dom';
import {
  ArrowLeft, Save, Send, AlertCircle, CheckCircle, 
  FileText, ChevronDown, ChevronRight, Clock, RefreshCw,
  Upload, Trash2, MessageSquare,
  AlertTriangle, Info, User, Building2
} from 'lucide-react';
import type { 
  CSMVendor, CSMAssessment, CSMFormDoc, CSMFormField, 
  CSMAssessmentAnswer, Company, CSMAuditor 
} from '../../../types';
import csmService from '../../../services/csmService';
import { csmVendorService } from '../../../services/csmVendorService';
import { enhancedCSMFormsService } from '../../../services/enhancedCsmService';
import { useToast } from '../../../hooks/useToast';
import { useAuth } from '../../../contexts/AuthContext';
import { ToastContainer } from '../../../components/ui/ToastContainer';
import { SkeletonLoader } from '../../../components/ui/SkeletonLoader';

// =================== TYPES ===================
interface EvaluationState {
  vendor: CSMVendor | null;
  company: Company | null;
  form: CSMFormDoc | null;
  assessment: CSMAssessment | null;
  answers: CSMAssessmentAnswer[];
  auditor: CSMAuditor;
  readOnly: boolean;
  isDirty: boolean;
  lastSaved: Date | null;
}
/*
interface ValidationError {
  field: string;
  message: string;
}*/

interface ScoreCalculation {
  totalScore: number;
  maxScore: number;
  percentage: number;
  completedQuestions: number;
  totalQuestions: number;
  riskLevel: 'Low' | 'Moderate' | 'High';
  categoryScores: Map<string, { score: number; max: number; percentage: number }>;
}

interface UIState {
  expandedSections: Set<string>;
  selectedQuestion: CSMFormField | null;
  showQuestionPanel: boolean;
  showSummaryModal: boolean;
  activeTab: 'questions' | 'summary' | 'history';
  viewMode: 'list' | 'grid';
  filterOptions: {
    showCompleted: boolean;
    showIncomplete: boolean;
    category: string;
  };
}

// =================== CONSTANTS ===================
const SCORE_OPTIONS = [
  { value: '0', label: '0 - ไม่เป็นไปตามข้อกำหนด', color: 'text-red-600', bgColor: 'bg-red-50', borderColor: 'border-red-200' },
  { value: '1', label: '1 - เป็นไปตามข้อกำหนดบางส่วน', color: 'text-orange-600', bgColor: 'bg-orange-50', borderColor: 'border-orange-200' },
  { value: '2', label: '2 - เป็นไปตามข้อกำหนดพอสมควร', color: 'text-yellow-600', bgColor: 'bg-yellow-50', borderColor: 'border-yellow-200' },
  { value: '3', label: '3 - เป็นไปตามข้อกำหนดดี', color: 'text-blue-600', bgColor: 'bg-blue-50', borderColor: 'border-blue-200' },
  { value: '4', label: '4 - เป็นไปตามข้องกำหนดดีมาก', color: 'text-green-600', bgColor: 'bg-green-50', borderColor: 'border-green-200' },
  { value: '5', label: '5 - เป็นไปตามข้อกำหนดดีเยี่ยม', color: 'text-green-700', bgColor: 'bg-green-100', borderColor: 'border-green-300' },
  { value: 'n/a', label: 'N/A - ไม่เกี่ยวข้อง', color: 'text-gray-500', bgColor: 'bg-gray-50', borderColor: 'border-gray-200' }
] as const;

const AUTO_SAVE_DELAY = 3000; // 3 seconds
const STORAGE_KEY = 'csm-evaluation-draft';

// =================== MAIN COMPONENT ===================
const CSMEvaluatePage: React.FC = () => {
  const { vdCode } = useParams<{ vdCode: string }>();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { toasts, addToast, removeToast } = useToast();
  const { user } = useAuth();
  
  // Get vdCode from params or query string
  const finalVdCode = vdCode || searchParams.get('vdCode');
  
  // State Management
  const [state, setState] = useState<EvaluationState>({
    vendor: null,
    company: null,
    form: null,
    assessment: null,
    answers: [],
    auditor: { 
      name: user?.displayName || '', 
      email: user?.email || '', 
      phone: '', 
      position: '' 
    },
    readOnly: false,
    isDirty: false,
    lastSaved: null
  });
  
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  
  // UI State
  const [uiState, setUIState] = useState<UIState>({
    expandedSections: new Set(),
    selectedQuestion: null,
    showQuestionPanel: false,
    showSummaryModal: false,
    activeTab: 'questions',
    viewMode: 'list',
    filterOptions: {
      showCompleted: true,
      showIncomplete: true,
      category: 'all'
    }
  });
  
  // Refs
  const isInitializedRef = useRef(false);
  const autoSaveTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const questionRefs = useRef<Map<string, HTMLDivElement>>(new Map());

  // =================== COMPUTED VALUES ===================
  
  // Group form fields by category
  const groupedFields = useMemo(() => {
    if (!state.form?.fields) return new Map();
    
    const groups = new Map<string, CSMFormField[]>();
    state.form.fields.forEach((field: CSMFormField) => {
      const groupKey = field.ckType || 'Other';
      if (!groups.has(groupKey)) {
        groups.set(groupKey, []);
      }
      groups.get(groupKey)!.push(field);
    });
    
    return groups;
  }, [state.form?.fields]);

  // Calculate comprehensive score metrics
  const scoreCalculation = useMemo((): ScoreCalculation => {
    if (!state.answers.length) {
      return {
        totalScore: 0,
        maxScore: 0,
        percentage: 0,
        completedQuestions: 0,
        totalQuestions: 0,
        riskLevel: 'High',
        categoryScores: new Map()
      };
    }

    const completed = state.answers.filter(answer => 
      answer.score && answer.score !== '0' && answer.score !== ''
    );
    
    const totalScore = completed.reduce((sum, answer) => {
      const score = answer.score === 'n/a' ? 0 : parseInt(answer.score || '0', 10) || 0;
      return sum + score;
    }, 0);
    
    const maxScore = state.answers.reduce((sum, answer) => {
      const maxForQuestion = parseInt(answer.tScore || '5', 10) || 5;
      return sum + maxForQuestion;
    }, 0);

    const percentage = maxScore > 0 ? (totalScore / maxScore) * 100 : 0;
    
    let riskLevel: 'Low' | 'Moderate' | 'High' = 'High';
    if (percentage >= 80) riskLevel = 'Low';
    else if (percentage >= 60) riskLevel = 'Moderate';

    // Calculate category scores
    const categoryScores = new Map<string, { score: number; max: number; percentage: number }>();
    groupedFields.forEach((fields, category) => {
      const categoryAnswers = fields.map((field: CSMFormField) => 
        state.answers.find(answer => answer.ckItem === field.ckItem)
      ).filter(Boolean) as CSMAssessmentAnswer[];
      
      const categoryCompleted = categoryAnswers.filter(answer => 
        answer.score && answer.score !== '0' && answer.score !== ''
      );
      
      const categoryTotalScore = categoryCompleted.reduce((sum, answer) => {
        const score = answer.score === 'n/a' ? 0 : parseInt(answer.score || '0', 10) || 0;
        return sum + score;
      }, 0);
      
      const categoryMaxScore = categoryAnswers.reduce((sum, answer) => {
        const maxForQuestion = parseInt(answer.tScore || '5', 10) || 5;
        return sum + maxForQuestion;
      }, 0);

      const categoryPercentage = categoryMaxScore > 0 ? (categoryTotalScore / categoryMaxScore) * 100 : 0;
      
      categoryScores.set(category, {
        score: categoryTotalScore,
        max: categoryMaxScore,
        percentage: categoryPercentage
      });
    });

    return {
      totalScore,
      maxScore,
      percentage,
      completedQuestions: completed.length,
      totalQuestions: state.answers.length,
      riskLevel,
      categoryScores
    };
  }, [state.answers, groupedFields]);

  // Filter questions based on UI state
  const filteredQuestions = useMemo(() => {
    const { filterOptions } = uiState;
    
    return Array.from(groupedFields.entries()).reduce((acc, [category, fields]) => {
      if (filterOptions.category !== 'all' && category !== filterOptions.category) {
        return acc;
      }
      
      const filteredFields = fields.filter((field: CSMFormField) => {
        const answer = state.answers.find(a => a.ckItem === field.ckItem);
        const isCompleted = answer?.score && answer.score !== '0' && answer.score !== '';
        
        if (!filterOptions.showCompleted && isCompleted) return false;
        if (!filterOptions.showIncomplete && !isCompleted) return false;
        
        return true;
      });
      
      if (filteredFields.length > 0) {
        acc.set(category, filteredFields);
      }
      
      return acc;
    }, new Map<string, CSMFormField[]>());
  }, [groupedFields, state.answers, uiState]);

  // =================== AUTO-SAVE FUNCTIONALITY ===================
  const handleSaveFunction = useCallback(async (isAutoSave = false) => {
    if (!state.assessment || !state.vendor || state.readOnly || saving) {
      console.log('Cannot save: missing data or read-only mode');
      return;
    }

    try {
      setSaving(true);
      
      const assessmentToSave: CSMAssessment = {
        ...state.assessment,
        answers: state.answers,
        auditor: state.auditor,
        updatedAt: new Date(),
        totalScore: scoreCalculation.totalScore.toString(),
        maxScore: scoreCalculation.maxScore.toString(),
        avgScore: scoreCalculation.percentage.toFixed(1)
      };

      console.log('💾 Saving assessment:', { 
        isAutoSave, 
        assessmentId: assessmentToSave.id,
        answersCount: assessmentToSave.answers.length 
      });

      const savedAssessment = await csmService.assessments.save(assessmentToSave);
      
      // Update state with saved assessment data
      setState(prev => ({
        ...prev,
        assessment: typeof savedAssessment === 'string' 
          ? { ...prev.assessment!, id: savedAssessment } 
          : savedAssessment,
        isDirty: false,
        lastSaved: new Date()
      }));

      // Save draft to localStorage for backup
      if (!isAutoSave) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify({
          vdCode: state.vendor.vdCode,
          answers: state.answers,
          auditor: state.auditor,
          timestamp: new Date().toISOString()
        }));
      }

      if (!isAutoSave) {
        addToast({
          type: 'success',
          title: 'บันทึกสำเร็จ',
          message: 'ข้อมูลการประเมินถูกบันทึกเรียบร้อยแล้ว',
          duration: 3000
        });
      }

      console.log('✅ Assessment saved successfully');
      
    } catch (error) {
      console.error('❌ Error saving assessment:', error);
      if (!isAutoSave) {
        addToast({
          type: 'error',
          title: 'เกิดข้อผิดพลาด',
          message: 'ไม่สามารถบันทึกข้อมูลได้ กรุณาลองใหม่อีกครั้ง',
          duration: 5000
        });
      }
    } finally {
      setSaving(false);
    }
  }, [state.assessment, state.vendor, state.readOnly, state.answers, state.auditor, scoreCalculation, saving, addToast]);

  useEffect(() => {
    if (state.isDirty && state.assessment && !state.readOnly && isInitializedRef.current) {
      // Clear existing timeout
      if (autoSaveTimeoutRef.current) {
        clearTimeout(autoSaveTimeoutRef.current);
      }
      
      // Set new timeout for auto-save
      autoSaveTimeoutRef.current = setTimeout(() => {
        handleSaveFunction(true); // true = auto-save
      }, AUTO_SAVE_DELAY);
    }
    
    return () => {
      if (autoSaveTimeoutRef.current) {
        clearTimeout(autoSaveTimeoutRef.current);
      }
    };
  }, [state.isDirty, state.assessment, state.readOnly, handleSaveFunction]);

  // =================== EVENT HANDLERS ===================
  
  // Save function with enhanced error handling
  const handleSave = useCallback(async (isAutoSave = false) => {
    return handleSaveFunction(isAutoSave);
  }, [handleSaveFunction]);

  // Submit function with validation
  const handleSubmit = useCallback(async () => {
    if (!state.assessment || state.readOnly || submitting) return;

    // Validate required fields
    const incompleteAnswers = state.answers.filter(answer => 
      !answer.score || answer.score === '0' || answer.score === ''
    );

    if (incompleteAnswers.length > 0) {
      addToast({
        type: 'warning',
        title: 'ข้อมูลไม่สมบูรณ์',
        message: `กรุณาให้คะแนนข้อคำถามที่ยังไม่สมบูรณ์ (${incompleteAnswers.length} ข้อ)`,
        duration: 5000
      });
      
      // Scroll to first incomplete question
      const firstIncomplete = incompleteAnswers[0];
      const questionElement = questionRefs.current.get(firstIncomplete.ckItem);
      if (questionElement) {
        questionElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
      return;
    }

    if (!state.auditor.name || !state.auditor.position) {
      addToast({
        type: 'warning',
        title: 'ข้อมูลผู้ประเมินไม่สมบูรณ์',
        message: 'กรุณากรอกชื่อและตำแหน่งผู้ประเมิน',
        duration: 5000
      });
      return;
    }

    // Show confirmation dialog
    const confirmSubmit = window.confirm(
      `คุณต้องการส่งการประเมินนี้หรือไม่?\n\n` +
      `ผลประเมิน: ${scoreCalculation.percentage.toFixed(1)}% (${scoreCalculation.totalScore}/${scoreCalculation.maxScore})\n` +
      `ระดับความเสี่ยง: ${scoreCalculation.riskLevel === 'Low' ? 'ต่ำ' : scoreCalculation.riskLevel === 'Moderate' ? 'ปานกลาง' : 'สูง'}\n\n` +
      `หลังจากส่งแล้วจะไม่สามารถแก้ไขได้อีก`
    );

    if (!confirmSubmit) return;

    try {
      setSubmitting(true);
      
      const finalAssessment: CSMAssessment = {
        ...state.assessment,
        answers: state.answers,
        auditor: state.auditor,
        isFinish: true,
        finishedAt: new Date(),
        updatedAt: new Date(),
        totalScore: scoreCalculation.totalScore.toString(),
        maxScore: scoreCalculation.maxScore.toString(),
        avgScore: scoreCalculation.percentage.toFixed(1)
      };

      await csmService.assessments.save(finalAssessment);
      
      // Clear draft from localStorage
      localStorage.removeItem(STORAGE_KEY);
      
      addToast({
        type: 'success',
        title: 'ส่งการประเมินสำเร็จ',
        message: 'การประเมิน CSM ถูกส่งเรียบร้อยแล้ว',
        duration: 5000
      });

      // Redirect to assessment detail or list/*
      /*
      setTimeout(() => {
        navigate('/csm');
      }, 2000);*/
      
    } catch (error) {
      console.error('Error submitting assessment:', error);
      addToast({
        type: 'error',
        title: 'เกิดข้อผิดพลาด',
        message: 'ไม่สามารถส่งการประเมินได้ กรุณาลองใหม่อีกครั้ง',
        duration: 5000
      });
    } finally {
      setSubmitting(false);
    }
  }, [state.assessment, state.readOnly, state.answers, state.auditor, scoreCalculation, submitting, addToast, navigate]);

  // Toggle section expansion
  const toggleSection = useCallback((sectionKey: string) => {
    setUIState(prev => ({
      ...prev,
      expandedSections: prev.expandedSections.has(sectionKey)
        ? new Set([...prev.expandedSections].filter(key => key !== sectionKey))
        : new Set([...prev.expandedSections, sectionKey])
    }));
  }, []);

  // Handle question selection
  const handleQuestionSelect = useCallback((field: CSMFormField) => {
    setUIState(prev => ({
      ...prev,
      selectedQuestion: field,
      showQuestionPanel: true
    }));
    
    // Scroll to question if in list view
    const questionElement = questionRefs.current.get(field.ckItem);
    if (questionElement) {
      questionElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  }, []);

  // Update answer
  const updateAnswer = useCallback((ckItem: string, field: keyof CSMAssessmentAnswer, value: string | boolean | string[]) => {
    setState(prev => ({
      ...prev,
      answers: prev.answers.map(answer =>
        answer.ckItem === ckItem 
          ? { ...answer, [field]: value }
          : answer
      ),
      isDirty: true
    }));
  }, []);

  // Update auditor
  const updateAuditor = useCallback((field: keyof CSMAuditor, value: string) => {
    setState(prev => ({
      ...prev,
      auditor: { ...prev.auditor, [field]: value },
      isDirty: true
    }));
  }, []);

  // =================== DATA LOADING ===================
  const loadData = useCallback(async () => {
    if (!finalVdCode || isInitializedRef.current) return;
    
    try {
      setLoading(true);
      console.log('🔄 Loading CSM evaluation data for vendor:', finalVdCode);

      // Get vendor with company data
      console.log('🔍 Getting vendor data...');
      const vendorWithCompany = await csmVendorService.getVendorWithCompany(vdCode || finalVdCode);
      
      if (!vendorWithCompany?.vendor) {
        console.error('❌ Vendor not found:', finalVdCode);
        addToast({
          type: 'error',
          title: 'ไม่พบข้อมูล',
          message: `ไม่พบข้อมูล vendor รหัส: ${finalVdCode}`,
          duration: 10000
        });
        //navigate('/csm');
        return;
      }

      console.log('✅ Found vendor:', vendorWithCompany.vendor);

      // Get CSM form
      console.log('🔍 Getting CSM form...');
      const csmForm = await enhancedCSMFormsService.getCSMChecklist();
      
      if (!csmForm) {
        console.error('❌ CSM form not found');
        addToast({
          type: 'error',
          title: 'ไม่พบแบบฟอร์ม',
          message: 'ไม่พบแบบฟอร์มประเมิน CSM',
          duration: 5000
        });
        return;
      }

      console.log('✅ Found CSM form:', csmForm.formTitle || csmForm.formCode);

      // Check for existing assessment
      console.log('🔍 Checking for existing assessments...');
      const existingAssessments = await csmService.assessments.getByVdCode(finalVdCode);
      
      const currentAssessment = existingAssessments.find((a: CSMAssessment) => 
        a.formId === csmForm.id && !a.isFinish
      );

      let assessment: CSMAssessment;
      let answers: CSMAssessmentAnswer[] = [];
      let auditor: CSMAuditor = {
        name: user?.displayName || '',
        email: user?.email || '',
        phone: '',
        position: ''
      };

      if (currentAssessment) {
        console.log('✅ Found existing assessment:', currentAssessment.id);
        assessment = currentAssessment;
        answers = currentAssessment.answers || [];
        auditor = currentAssessment.auditor || auditor;
      } else {
        console.log('🔍 Creating new assessment');
        assessment = {
          id: '',
          companyId: vendorWithCompany.vendor.companyId,
          vdCode: vendorWithCompany.vendor.vdCode,
          vdName: vendorWithCompany.vendor.vdName,
          formId: csmForm.id || '',
          formVersion: '1.0',
          answers: [],
          auditor,
          vdCategory: vendorWithCompany.vendor.category,
          vdWorkingArea: vendorWithCompany.vendor.workingArea?.join(', ') || '',
          isActive: true,
          isFinish: false,
          createdAt: new Date(),
          updatedAt: new Date(),
          totalScore: '0',
          maxScore: '0',
          avgScore: '0'
        };

        // Initialize answers for all form fields
        answers = csmForm.fields.map((field: CSMFormField) => ({
          ckItem: field.ckItem,
          ckType: field.ckType,
          ckQuestion: field.ckQuestion,
          comment: '',
          score: '',
          tScore: field.fScore || field.tScore || '5',
          files: [],
          isFinish: false
        }));
      }

      // Check for draft in localStorage
      const draftData = localStorage.getItem(STORAGE_KEY);
      if (draftData && !currentAssessment) {
        try {
          const draft = JSON.parse(draftData);
          if (draft.vdCode === finalVdCode) {
            console.log('📝 Found draft data, applying...');
            if (draft.answers) answers = draft.answers;
            if (draft.auditor) auditor = { ...auditor, ...draft.auditor };
            
            addToast({
              type: 'info',
              title: 'พบข้อมูลร่าง',
              message: 'ข้อมูลการประเมินที่ยังไม่ได้บันทึกถูกโหลดคืนมา',
              duration: 5000
            });
          }
        } catch (error) {
          console.warn('Failed to parse draft data:', error);
        }
      }

      // Initialize expanded sections
      const sections = new Set(csmForm.fields.map((f: CSMFormField) => f.ckType).filter(Boolean) as string[]);
      
      // Set state
      setState({
        vendor: vendorWithCompany.vendor,
        company: vendorWithCompany.company,
        form: csmForm,
        assessment,
        answers,
        auditor,
        readOnly: currentAssessment?.isFinish || false,
        isDirty: false,
        lastSaved: currentAssessment ? new Date(currentAssessment.updatedAt as Date) : null
      });

      setUIState(prev => ({
        ...prev,
        expandedSections: sections
      }));

      isInitializedRef.current = true;
      console.log('✅ Data loading completed successfully!');

    } catch (error) {
      console.error('❌ Error loading evaluation data:', error);
      addToast({
        type: 'error',
        title: 'เกิดข้อผิดพลาด',
        message: 'ไม่สามารถโหลดข้อมูลการประเมินได้',
        duration: 5000
      });
    } finally {
      setLoading(false);
    }
  }, [finalVdCode, navigate, addToast, user]);

  // =================== EFFECTS ===================
  useEffect(() => {
    if (finalVdCode && !isInitializedRef.current) {
      loadData();
    }
  }, [finalVdCode, loadData]);

  // Cleanup autosave timeout on unmount
  useEffect(() => {
    return () => {
      if (autoSaveTimeoutRef.current) {
        clearTimeout(autoSaveTimeoutRef.current);
      }
    };
  }, []);

  // =================== RENDER FUNCTIONS ===================
  
  const renderVendorInfo = () => (
    <div className="overflow-hidden bg-white border shadow-sm rounded-xl">
      <div className="px-6 py-4 border-b bg-gradient-to-r from-blue-50 to-indigo-50">
        <div className="flex items-center space-x-3">
          <Building2 className="w-6 h-6 text-blue-600" />
          <h2 className="text-lg font-semibold text-gray-900">ข้อมูลผู้ให้บริการ</h2>
        </div>
      </div>
      <div className="p-6">
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
          <div className="space-y-1">
            <label className="block text-sm font-medium text-gray-700">
              รหัสผู้ให้บริการ
            </label>
            <p className="px-3 py-2 font-mono text-lg font-semibold text-blue-600 rounded-lg bg-blue-50">
              {state.vendor?.vdCode}
            </p>
          </div>
          <div className="space-y-1">
            <label className="block text-sm font-medium text-gray-700">
              ชื่อผู้ให้บริการ
            </label>
            <p className="px-3 py-2 text-lg text-gray-900 rounded-lg bg-gray-50">
              {state.vendor?.vdName}
            </p>
          </div>
          <div className="space-y-1">
            <label className="block text-sm font-medium text-gray-700">
              ประเภทงาน
            </label>
            <div className="flex items-center space-x-2">
              <span className="inline-flex items-center px-3 py-1 text-sm font-medium text-indigo-800 bg-indigo-100 rounded-full">
                {state.vendor?.category}
              </span>
            </div>
          </div>
          <div className="space-y-1">
            <label className="block text-sm font-medium text-gray-700">
              พื้นที่ปฏิบัติงาน
            </label>
            <p className="px-3 py-2 text-gray-900 rounded-lg bg-gray-50">
              {state.vendor?.workingArea?.join(', ') || 'ไม่ระบุ'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );

  const renderAuditorSection = () => (
    <div className="overflow-hidden bg-white border shadow-sm rounded-xl">
      <div className="px-6 py-4 border-b bg-gradient-to-r from-green-50 to-emerald-50">
        <div className="flex items-center space-x-3">
          <User className="w-6 h-6 text-green-600" />
          <h2 className="text-lg font-semibold text-gray-900">ข้อมูลผู้ประเมิน</h2>
        </div>
      </div>
      <div className="p-6">
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700">
              ชื่อผู้ประเมิน <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={state.auditor.name}
              onChange={(e) => updateAuditor('name', e.target.value)}
              disabled={state.readOnly}
              className="w-full px-4 py-3 transition-colors border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:bg-gray-50 disabled:text-gray-500"
              placeholder="กรอกชื่อผู้ประเมิน"
            />
          </div>
          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700">
              อีเมล
            </label>
            <input
              type="email"
              value={state.auditor.email}
              onChange={(e) => updateAuditor('email', e.target.value)}
              disabled={state.readOnly}
              className="w-full px-4 py-3 transition-colors border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:bg-gray-50 disabled:text-gray-500"
              placeholder="กรอกอีเมล"
            />
          </div>
          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700">
              เบอร์โทรศัพท์
            </label>
            <input
              type="tel"
              value={state.auditor.phone}
              onChange={(e) => updateAuditor('phone', e.target.value)}
              disabled={state.readOnly}
              className="w-full px-4 py-3 transition-colors border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:bg-gray-50 disabled:text-gray-500"
              placeholder="กรอกเบอร์โทรศัพท์"
            />
          </div>
          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700">
              ตำแหน่ง <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={state.auditor.position}
              onChange={(e) => updateAuditor('position', e.target.value)}
              disabled={state.readOnly}
              className="w-full px-4 py-3 transition-colors border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:bg-gray-50 disabled:text-gray-500"
              placeholder="กรอกตำแหน่ง"
            />
          </div>
        </div>
      </div>
    </div>
  );

  const renderSummarySection = () => (
    <div className="overflow-hidden bg-white border shadow-sm rounded-xl">
      <div className="px-6 py-4 border-b bg-gradient-to-r from-purple-50 to-pink-50">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <CheckCircle className="w-6 h-6 text-purple-600" />
            <h2 className="text-lg font-semibold text-gray-900">สรุปผลการประเมิน</h2>
          </div>
          {state.lastSaved && (
            <div className="flex items-center space-x-2 text-sm text-gray-500">
              <Clock className="w-4 h-4" />
              <span>บันทึกล่าสุด: {state.lastSaved.toLocaleTimeString('th-TH')}</span>
            </div>
          )}
        </div>
      </div>
      
      <div className="p-6">
        {scoreCalculation.completedQuestions > 0 ? (
          <div className="space-y-6">
            {/* Overall Score */}
            <div className="grid grid-cols-1 gap-4 md:grid-cols-4">
              <div className="p-4 text-center bg-gray-50 rounded-xl">
                <div className="mb-2 text-3xl font-bold text-gray-900">
                  {scoreCalculation.completedQuestions}
                </div>
                <div className="text-sm text-gray-600">ข้อที่เสร็จสิ้น</div>
                <div className="mt-1 text-xs text-gray-500">
                  จาก {scoreCalculation.totalQuestions} ข้อ
                </div>
              </div>
              
              <div className="p-4 text-center bg-blue-50 rounded-xl">
                <div className="mb-2 text-3xl font-bold text-blue-900">
                  {scoreCalculation.totalScore}
                </div>
                <div className="text-sm text-blue-600">คะแนนรวม</div>
                <div className="mt-1 text-xs text-blue-500">
                  จาก {scoreCalculation.maxScore} คะแนน
                </div>
              </div>
              
              <div className="p-4 text-center bg-green-50 rounded-xl">
                <div className="mb-2 text-3xl font-bold text-green-900">
                  {scoreCalculation.percentage.toFixed(1)}%
                </div>
                <div className="text-sm text-green-600">เปอร์เซ็นต์</div>
                <div className="mt-1 text-xs text-green-500">
                  ค่าเฉลี่ย
                </div>
              </div>
              
              <div className={`text-center p-4 rounded-xl ${
                scoreCalculation.riskLevel === 'Low' ? 'bg-green-50' :
                scoreCalculation.riskLevel === 'Moderate' ? 'bg-yellow-50' : 'bg-red-50'
              }`}>
                <div className={`text-3xl font-bold mb-2 ${
                  scoreCalculation.riskLevel === 'Low' ? 'text-green-900' :
                  scoreCalculation.riskLevel === 'Moderate' ? 'text-yellow-900' : 'text-red-900'
                }`}>
                  {scoreCalculation.riskLevel === 'Low' ? 'ต่ำ' :
                   scoreCalculation.riskLevel === 'Moderate' ? 'ปานกลาง' : 'สูง'}
                </div>
                <div className={`text-sm ${
                  scoreCalculation.riskLevel === 'Low' ? 'text-green-600' :
                  scoreCalculation.riskLevel === 'Moderate' ? 'text-yellow-600' : 'text-red-600'
                }`}>
                  ระดับความเสี่ยง
                </div>
              </div>
            </div>

            {/* Progress by Category */}
            <div>
              <h4 className="mb-4 font-semibold text-gray-900 text-md">ความคืบหน้าตามหมวด</h4>
              <div className="space-y-4">
                {Array.from(scoreCalculation.categoryScores.entries()).map(([category, scores]) => (
                  <div key={category} className="flex items-center space-x-4">
                    <div className="flex-shrink-0 w-24 text-sm font-medium text-gray-700">
                      {category}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm text-gray-600">
                          {scores.score}/{scores.max}
                        </span>
                        <span className="text-sm font-medium text-gray-900">
                          {scores.percentage.toFixed(1)}%
                        </span>
                      </div>
                      <div className="w-full h-3 bg-gray-200 rounded-full">
                        <div 
                          className={`h-3 rounded-full transition-all duration-500 ${
                            scores.percentage >= 80 ? 'bg-green-500' :
                            scores.percentage >= 60 ? 'bg-yellow-500' : 'bg-red-500'
                          }`}
                          style={{ width: `${Math.min(scores.percentage, 100)}%` }}
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Overall Progress Bar */}
            <div className="p-4 bg-gray-50 rounded-xl">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-medium text-gray-700">ความคืบหน้าโดยรวม</span>
                <span className="text-sm font-bold text-gray-900">
                  {Math.round((scoreCalculation.completedQuestions / scoreCalculation.totalQuestions) * 100)}%
                </span>
              </div>
              <div className="w-full h-4 bg-gray-200 rounded-full">
                <div 
                  className="relative h-4 overflow-hidden transition-all duration-700 rounded-full bg-gradient-to-r from-blue-500 to-purple-600"
                  style={{ 
                    width: `${(scoreCalculation.completedQuestions / scoreCalculation.totalQuestions) * 100}%` 
                  }}
                >
                  <div className="absolute inset-0 bg-white bg-opacity-30 animate-pulse"></div>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="py-8 text-center">
            <AlertCircle className="w-16 h-16 mx-auto mb-4 text-gray-400" />
            <h3 className="mb-2 text-lg font-medium text-gray-900">ยังไม่มีข้อมูลการประเมิน</h3>
            <p className="text-gray-600">เริ่มตอบคำถามเพื่อดูสรุปผลการประเมิน</p>
          </div>
        )}
      </div>
    </div>
  );

  const renderQuestionItem = (field: CSMFormField) => {
    const answer = state.answers.find(a => a.ckItem === field.ckItem);
    if (!answer) return null;

    const isCompleted = answer.score && answer.score !== '0' && answer.score !== '';
    const hasComment = answer.comment && answer.comment.trim().length > 0;
    const isSelected = uiState.selectedQuestion?.ckItem === field.ckItem;

    return (
      <div 
        key={field.ckItem}
        ref={el => {
          if (el) questionRefs.current.set(field.ckItem, el);
        }}
        className={`group p-6 border-l-4 cursor-pointer transition-all duration-300 hover:bg-gray-50 ${
          isSelected 
            ? 'bg-blue-50 border-blue-500 shadow-md' 
            : isCompleted
              ? 'border-green-400 bg-green-50/30'
              : hasComment
                ? 'border-yellow-400 bg-yellow-50/30'
                : 'border-gray-200 hover:border-blue-300'
        }`}
        onClick={() => handleQuestionSelect(field)}
      >
        <div className="flex items-start justify-between">
          <div className="flex-1 min-w-0">
            <div className="flex items-center mb-3 space-x-3">
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                ข้อ {field.ckItem}
              </span>
              <div className={`w-3 h-3 rounded-full transition-colors ${
                isCompleted ? 'bg-green-500' : hasComment ? 'bg-yellow-500' : 'bg-gray-300'
              }`} />
              {field.ckType && (
                <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${
                  field.ckType === 'M' ? 'bg-blue-100 text-blue-800' :
                  field.ckType === 'P' ? 'bg-purple-100 text-purple-800' :
                  'bg-gray-100 text-gray-800'
                }`}>
                  {field.ckType}
                </span>
              )}
            </div>
            <h4 className="mb-2 font-medium text-gray-900 transition-colors line-clamp-2 group-hover:text-blue-600">
              {field.ckQuestion}
            </h4>
            {field.ckRequirement && (
              <p className="mb-3 text-sm text-gray-600 line-clamp-2">
                {field.ckRequirement}
              </p>
            )}
            {hasComment && (
              <div className="flex items-center space-x-2 text-sm text-gray-500">
                <MessageSquare className="w-4 h-4" />
                <span>มีความเห็นเพิ่มเติม</span>
              </div>
            )}
          </div>
          <div className="flex items-center ml-4 space-x-3">
            {answer.score && answer.score !== '0' && (
              <div className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold transition-transform group-hover:scale-110 ${
                answer.score === 'n/a' ? 'bg-gray-100 text-gray-600' :
                parseInt(answer.score) >= 4 ? 'bg-green-100 text-green-600' :
                parseInt(answer.score) >= 2 ? 'bg-yellow-100 text-yellow-600' :
                'bg-red-100 text-red-600'
              }`}>
                {answer.score}
              </div>
            )}
            <div className="text-gray-400 transition-colors group-hover:text-blue-500">
              <ChevronRight className="w-5 h-5" />
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderQuestionPanel = () => {
    if (!uiState.selectedQuestion || !uiState.showQuestionPanel) return null;

    const answer = state.answers.find(a => a.ckItem === uiState.selectedQuestion?.ckItem);
    if (!answer) return null;

    const selectedScore = SCORE_OPTIONS.find(opt => opt.value === answer.score);

    return (
      <div className="overflow-hidden bg-white border shadow-sm rounded-xl">
        <div className="px-6 py-4 border-b bg-gradient-to-r from-indigo-50 to-blue-50">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-semibold text-gray-900">
                ข้อที่ {uiState.selectedQuestion.ckItem}
              </h3>
              <p className="mt-1 text-sm text-gray-600">
                น้ำหนักคะแนน: {uiState.selectedQuestion.fScore || uiState.selectedQuestion.tScore || '5'} คะแนน
              </p>
            </div>
            <button
              onClick={() => setUIState(prev => ({ ...prev, showQuestionPanel: false }))}
              className="text-gray-400 transition-colors hover:text-gray-600 lg:hidden"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>

        <div className="p-6 space-y-6">
          {/* Question Details */}
          <div className="space-y-4">
            <div>
              <h4 className="flex items-center mb-3 font-medium text-gray-900">
                <FileText className="w-5 h-5 mr-2 text-blue-600" />
                คำถาม
              </h4>
              <div className="p-4 border-l-4 border-blue-400 rounded-lg bg-gray-50">
                <p className="leading-relaxed text-gray-800">
                  {uiState.selectedQuestion.ckQuestion}
                </p>
              </div>
            </div>

            {uiState.selectedQuestion.ckRequirement && (
              <div>
                <h4 className="flex items-center mb-3 font-medium text-gray-900">
                  <Info className="w-5 h-5 mr-2 text-green-600" />
                  เกณฑ์การประเมิน
                </h4>
                <div className="p-4 border-l-4 border-blue-400 rounded-lg bg-blue-50">
                  <p className="leading-relaxed text-blue-800">
                    {uiState.selectedQuestion.ckRequirement}
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Score Selection */}
          <div>
            <label className="flex items-center block mb-4 text-sm font-semibold text-gray-700">
              <span className="mr-1 text-red-500">*</span>
              คะแนน
              {selectedScore && (
                <span className="ml-2 text-xs text-gray-500">
                  (เลือกแล้ว: {selectedScore.label})
                </span>
              )}
            </label>
            <div className="grid grid-cols-1 gap-3">
              {SCORE_OPTIONS.map((option) => (
                <button
                  key={option.value}
                  type="button"
                  onClick={() => updateAnswer(uiState.selectedQuestion?.ckItem || '', 'score', option.value)}
                  disabled={state.readOnly}
                  className={`p-4 text-left border-2 rounded-xl transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed hover:shadow-md ${
                    answer.score === option.value
                      ? `${option.borderColor} ${option.bgColor} shadow-md scale-[1.02]`
                      : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                  }`}
                >
                  <div className="flex items-center space-x-4">
                    <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-colors ${
                      answer.score === option.value 
                        ? 'border-blue-500 bg-blue-500' 
                        : 'border-gray-300'
                    }`}>
                      {answer.score === option.value && (
                        <div className="w-2 h-2 bg-white rounded-full" />
                      )}
                    </div>
                    <div className="flex-1">
                      <span className={`text-sm font-medium ${option.color}`}>
                        {option.label}
                      </span>
                    </div>
                    {answer.score === option.value && (
                      <CheckCircle className="w-5 h-5 text-blue-500" />
                    )}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Comment Section */}
          <div>
            <label className="flex items-center block mb-3 text-sm font-medium text-gray-700">
              <MessageSquare className="w-5 h-5 mr-2 text-gray-600" />
              ความเห็น/หลักฐาน/ข้อเสนอแนะ
            </label>
            <textarea
              value={answer.comment || ''}
              onChange={(e) => updateAnswer(uiState.selectedQuestion?.ckItem || '', 'comment', e.target.value)}
              disabled={state.readOnly}
              rows={4}
              className="w-full px-4 py-3 transition-colors border border-gray-300 rounded-lg resize-none focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:bg-gray-50 disabled:text-gray-500"
              placeholder="กรอกความเห็น หลักฐานประกอบ หรือข้อเสนอแนะ..."
            />
          </div>

          {/* File Upload Section */}
          <div>
            <label className="flex items-center block mb-3 text-sm font-medium text-gray-700">
              <Upload className="w-5 h-5 mr-2 text-gray-600" />
              ไฟล์แนบ
            </label>
            {!state.readOnly ? (
              <div className="p-6 text-center transition-colors border-2 border-gray-300 border-dashed rounded-lg hover:border-gray-400 bg-gray-50 hover:bg-gray-100">
                <input
                  type="file"
                  multiple
                  accept="image/*,.pdf,.doc,.docx,.xls,.xlsx"
                  onChange={(e) => {
                    const files = Array.from(e.target.files || []);
                    console.log('Files selected:', files);
                    // TODO: Implement file upload logic
                  }}
                  className="hidden"
                  id={`file-upload-${uiState.selectedQuestion.ckItem}`}
                />
                <label 
                  htmlFor={`file-upload-${uiState.selectedQuestion.ckItem}`}
                  className="flex flex-col items-center cursor-pointer"
                >
                  <Upload className="w-10 h-10 mb-3 text-gray-400" />
                  <span className="mb-1 text-sm font-medium text-gray-700">คลิกเพื่อเลือกไฟล์</span>
                  <span className="text-xs text-gray-500">รองรับ: รูปภาพ, PDF, Word, Excel (ขนาดไม่เกิน 10MB)</span>
                </label>
              </div>
            ) : (
              <div className="p-4 text-sm text-gray-500 border rounded-lg bg-gray-50">
                ไม่สามารถแก้ไขไฟล์แนบได้ในโหมดอ่านอย่างเดียว
              </div>
            )}

            {/* Show existing files */}
            {answer.files && answer.files.length > 0 && (
              <div className="mt-4 space-y-2">
                <p className="text-sm font-medium text-gray-700">ไฟล์ที่แนบ:</p>
                {answer.files.map((_file, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-white border border-gray-200 rounded-lg shadow-sm">
                    <div className="flex items-center space-x-3">
                      <div className="flex items-center justify-center w-8 h-8 bg-blue-100 rounded-lg">
                        <FileText className="w-4 h-4 text-blue-600" />
                      </div>
                      <span className="text-sm font-medium text-gray-700 truncate">
                        ไฟล์ {index + 1}
                      </span>
                    </div>
                    {!state.readOnly && (
                      <button 
                        className="p-1 text-red-500 transition-colors rounded hover:text-red-700"
                        onClick={() => {
                          const newFiles = answer.files?.filter((_, i) => i !== index) || [];
                          updateAnswer(uiState.selectedQuestion?.ckItem|| '', 'files', newFiles);
                        }}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Completion Status */}
          {!state.readOnly && (
            <div className="p-4 border border-green-200 bg-gradient-to-r from-green-50 to-blue-50 rounded-xl">
              <div className="flex items-center space-x-3">
                <input
                  type="checkbox"
                  id={`complete-${uiState.selectedQuestion?.ckItem}`}
                  checked={answer.isFinish || false}
                  onChange={(e) => updateAnswer(uiState.selectedQuestion?.ckItem|| '', 'isFinish', e.target.checked)}
                  className="w-5 h-5 text-green-600 border-gray-300 rounded focus:ring-green-500 focus:ring-2"
                />
                <label 
                  htmlFor={`complete-${uiState.selectedQuestion.ckItem}`}
                  className="flex items-center text-sm font-medium text-gray-700 cursor-pointer"
                >
                  <CheckCircle className="w-5 h-5 mr-2 text-green-600" />
                  ยืนยันว่าข้อนี้ประเมินเสร็จสิ้นแล้ว
                </label>
              </div>
            </div>
          )}

          {/* Question Navigation */}
          <div className="flex items-center justify-between pt-4 border-t">
            <div className="text-sm text-gray-600">
              ข้อที่ {uiState.selectedQuestion.ckItem} จาก {state.answers.length}
            </div>
            <div className="flex space-x-2">
              <button
                onClick={() => {
                  const currentIndex = state.form?.fields.findIndex(f => f.ckItem === uiState.selectedQuestion?.ckItem) || 0;
                  if (currentIndex > 0 && state.form?.fields) {
                    handleQuestionSelect(state.form.fields[currentIndex - 1]);
                  }
                }}
                disabled={!state.form?.fields || state.form.fields.findIndex(f => f.ckItem === uiState.selectedQuestion?.ckItem) === 0}
                className="px-3 py-1.5 text-sm bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                ← ก่อนหน้า
              </button>
              <button
                onClick={() => {
                  const currentIndex = state.form?.fields.findIndex(f => f.ckItem === uiState.selectedQuestion?.ckItem) || 0;
                  if (currentIndex < (state.form?.fields?.length || 0) - 1 && state.form?.fields) {
                    handleQuestionSelect(state.form.fields[currentIndex + 1]);
                  }
                }}
                disabled={!state.form?.fields || state.form.fields.findIndex(f => f.ckItem === uiState.selectedQuestion?.ckItem) === state.form.fields.length - 1}
                className="px-3 py-1.5 text-sm bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                ถัดไป →
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderQuestionsSection = () => (
    <div className="grid grid-cols-12 gap-6">
      {/* Questions List - Left Side */}
      <div className="col-span-12 lg:col-span-7">
        <div className="space-y-4">
          {/* Filter Controls */}
          <div className="p-4 bg-white border shadow-sm rounded-xl">
            <div className="flex flex-wrap items-center gap-4">
              <div className="flex items-center space-x-2">
                <label className="text-sm font-medium text-gray-700">แสดง:</label>
                <div className="flex items-center space-x-3">
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      checked={uiState.filterOptions.showCompleted}
                      onChange={(e) => setUIState(prev => ({
                        ...prev,
                        filterOptions: { ...prev.filterOptions, showCompleted: e.target.checked }
                      }))}
                      className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                    />
                    <span className="ml-2 text-sm text-gray-600">เสร็จแล้ว</span>
                  </label>
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      checked={uiState.filterOptions.showIncomplete}
                      onChange={(e) => setUIState(prev => ({
                        ...prev,
                        filterOptions: { ...prev.filterOptions, showIncomplete: e.target.checked }
                      }))}
                      className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                    />
                    <span className="ml-2 text-sm text-gray-600">ยังไม่เสร็จ</span>
                  </label>
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                <label className="text-sm font-medium text-gray-700">หมวด:</label>
                <select
                  value={uiState.filterOptions.category}
                  onChange={(e) => setUIState(prev => ({
                    ...prev,
                    filterOptions: { ...prev.filterOptions, category: e.target.value }
                  }))}
                  className="px-3 py-1.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="all">ทั้งหมด</option>
                  {Array.from(groupedFields.keys()).map(category => (
                    <option key={category} value={category}>{category}</option>
                  ))}
                </select>
              </div>

              <div className="flex items-center ml-auto space-x-2">
                <button
                  onClick={() => setUIState(prev => ({
                    ...prev,
                    expandedSections: new Set(groupedFields.keys())
                  }))}
                  className="px-3 py-1.5 text-sm text-blue-600 hover:text-blue-800 transition-colors"
                >
                  ขยายทั้งหมด
                </button>
                <button
                  onClick={() => setUIState(prev => ({
                    ...prev,
                    expandedSections: new Set()
                  }))}
                  className="px-3 py-1.5 text-sm text-blue-600 hover:text-blue-800 transition-colors"
                >
                  ย่อทั้งหมด
                </button>
              </div>
            </div>
          </div>

          {/* Questions by Section */}
          {Array.from(filteredQuestions.entries()).map(([sectionKey, fields]: [string, CSMFormField[]]) => {
            const isExpanded = uiState.expandedSections.has(sectionKey);
            const sectionAnswers = fields.map((field: CSMFormField) => 
              state.answers.find(answer => answer.ckItem === field.ckItem)
            ).filter(Boolean) as CSMAssessmentAnswer[];
            
            const completedInSection = sectionAnswers.filter(answer => 
              answer.score && answer.score !== '0' && answer.score !== ''
            ).length;

            const categoryScore = scoreCalculation.categoryScores.get(sectionKey);

            return (
              <div key={sectionKey} className="overflow-hidden transition-all duration-300 bg-white border shadow-sm rounded-xl">
                <button
                  type="button"
                  onClick={() => toggleSection(sectionKey)}
                  className="flex items-center justify-between w-full p-6 text-left transition-colors hover:bg-gray-50 group"
                >
                  <div className="flex items-center space-x-4">
                    <div className={`w-14 h-14 rounded-xl flex items-center justify-center transition-all duration-300 ${
                      completedInSection === fields.length
                        ? 'bg-green-100 text-green-700 group-hover:bg-green-200'
                        : completedInSection > 0
                          ? 'bg-yellow-100 text-yellow-700 group-hover:bg-yellow-200'
                          : 'bg-gray-100 text-gray-600 group-hover:bg-gray-200'
                    }`}>
                      {completedInSection === fields.length ? (
                        <CheckCircle className="w-7 h-7" />
                      ) : (
                        <span className="text-lg font-bold">{sectionKey.substring(0, 1)}</span>
                      )}
                    </div>
                    
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-900 transition-colors group-hover:text-blue-600">
                        หมวด {sectionKey}
                      </h3>
                      <div className="flex items-center mt-1 space-x-4">
                        <p className="text-sm text-gray-600">
                          {completedInSection}/{fields.length} ข้อเสร็จสิ้น
                        </p>
                        {categoryScore && (
                          <p className="text-sm font-medium text-gray-700">
                            คะแนน: {categoryScore.score}/{categoryScore.max} ({categoryScore.percentage.toFixed(1)}%)
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-4">
                    <div className="text-right">
                      <div className="w-32 h-3 mb-1 bg-gray-200 rounded-full">
                        <div 
                          className={`h-3 rounded-full transition-all duration-500 ${
                            completedInSection === fields.length ? 'bg-green-500' :
                            completedInSection > 0 ? 'bg-yellow-500' : 'bg-gray-400'
                          }`}
                          style={{ width: `${(completedInSection / fields.length) * 100}%` }}
                        />
                      </div>
                      <span className="text-xs text-gray-500">
                        {Math.round((completedInSection / fields.length) * 100)}%
                      </span>
                    </div>
                    
                    <div className={`transform transition-transform duration-300 ${isExpanded ? 'rotate-90' : ''}`}>
                      {isExpanded ? (
                        <ChevronDown className="w-6 h-6 text-gray-400 group-hover:text-blue-500" />
                      ) : (
                        <ChevronRight className="w-6 h-6 text-gray-400 group-hover:text-blue-500" />
                      )}
                    </div>
                  </div>
                </button>

                {isExpanded && (
                  <div className="border-t border-gray-100 bg-gray-50/50">
                    <div className="p-4 space-y-2">
                      {fields.map((field: CSMFormField) => renderQuestionItem(field))}
                    </div>
                  </div>
                )}
              </div>
            );
          })}

          {filteredQuestions.size === 0 && (
            <div className="p-8 text-center bg-white border shadow-sm rounded-xl">
              <AlertCircle className="w-12 h-12 mx-auto mb-4 text-gray-400" />
              <h3 className="mb-2 text-lg font-medium text-gray-900">ไม่พบคำถามที่ตรงกับเงื่อนไข</h3>
              <p className="text-gray-600">ลองปรับเปลี่ยนตัวกรองเพื่อดูคำถามอื่น</p>
            </div>
          )}
        </div>
      </div>

      {/* Question Detail Panel - Right Side */}
      <div className="col-span-12 lg:col-span-5">
        <div className="sticky top-6">
          {uiState.showQuestionPanel && uiState.selectedQuestion ? (
            renderQuestionPanel()
          ) : (
            <div className="p-12 text-center border-2 border-gray-300 border-dashed bg-gray-50 rounded-xl">
              <FileText className="w-16 h-16 mx-auto mb-4 text-gray-400" />
              <h3 className="mb-2 text-lg font-medium text-gray-900">เลือกคำถามเพื่อตอบ</h3>
              <p className="mb-4 text-gray-600">คลิกที่คำถามใด ๆ ทางด้านซ้าย เพื่อแสดงรายละเอียดและตอบคำถาม</p>
              <div className="text-sm text-gray-500">
                <p>💡 <strong>เคล็ดลับ:</strong> ใช้ checkbox เพื่อกรองคำถามที่ต้องการดู</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );

  // =================== MAIN RENDER ===================
  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="px-6 py-8 mx-auto max-w-7xl">
          <div className="space-y-6 animate-pulse">
            <SkeletonLoader className="w-64 h-8" />
            <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
              <SkeletonLoader className="h-48" />
              <SkeletonLoader className="h-48" />
            </div>
            <SkeletonLoader className="h-64" />
            <SkeletonLoader className="h-96" />
          </div>
        </div>
      </div>
    );
  }

  if (!state.vendor || !state.form) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50">
        <div className="max-w-md text-center">
          <AlertTriangle className="w-20 h-20 mx-auto mb-6 text-red-500" />
          <h2 className="mb-4 text-2xl font-bold text-gray-900">ไม่พบข้อมูล</h2>
          <p className="mb-6 text-gray-600">
            ไม่สามารถโหลดข้อมูลการประเมินได้ อาจเป็นเพราะ:
          </p>
          <ul className="mb-6 space-y-1 text-left text-gray-600">
            <li>• ไม่พบข้อมูลผู้ให้บริการ</li>
            <li>• ไม่พบแบบฟอร์มประเมิน</li>
            <li>• เกิดข้อผิดพลาดในการเชื่อมต่อ</li>
          </ul>
          <div className="space-x-3">
            <button
              onClick={() => window.location.reload()}
              className="inline-flex items-center px-6 py-3 text-white transition-colors bg-blue-600 rounded-lg hover:bg-blue-700"
            >
              <RefreshCw className="w-4 h-4 mr-2" />
              ลองใหม่
            </button>
            <button
              onClick={() => navigate('/csm')}
              className="px-6 py-3 text-gray-700 transition-colors bg-gray-200 rounded-lg hover:bg-gray-300"
            >
              กลับหน้าหลัก
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <ToastContainer toasts={toasts} onRemove={removeToast} />

      {/* Header */}
      <div className="sticky top-0 z-10 bg-white border-b shadow-sm">
        <div className="px-6 py-4 mx-auto max-w-7xl">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => navigate('/csm')}
                className="p-2 text-gray-500 transition-colors hover:text-gray-700 hover:bg-gray-100 rounded-xl"
              >
                <ArrowLeft className="w-6 h-6" />
              </button>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">
                  ประเมิน CSM: {state.vendor.vdName}
                </h1>
                <div className="flex items-center mt-1 space-x-4 text-sm text-gray-600">
                  <span className="flex items-center">
                    <Building2 className="w-4 h-4 mr-1" />
                    รหัส: {state.vendor.vdCode}
                  </span>
                  <span>•</span>
                  <span className="flex items-center">
                    <FileText className="w-4 h-4 mr-1" />
                    แบบฟอร์ม: {state.form.formTitle || state.form.formCode}
                  </span>
                  {state.readOnly && (
                    <>
                      <span>•</span>
                      <span className="inline-flex items-center px-2 py-1 text-xs font-medium text-green-800 bg-green-100 rounded-full">
                        <CheckCircle className="w-3 h-3 mr-1" />
                        เสร็จสิ้นแล้ว
                      </span>
                    </>
                  )}
                  {state.isDirty && !state.readOnly && (
                    <>
                      <span>•</span>
                      <span className="inline-flex items-center px-2 py-1 text-xs font-medium text-yellow-800 bg-yellow-100 rounded-full">
                        <Clock className="w-3 h-3 mr-1" />
                        มีการเปลี่ยนแปลง
                      </span>
                    </>
                  )}
                </div>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              {state.lastSaved && (
                <div className="items-center hidden space-x-2 text-sm text-gray-500 md:flex">
                  <Clock className="w-4 h-4" />
                  <span>บันทึกล่าสุด: {state.lastSaved.toLocaleTimeString('th-TH')}</span>
                </div>
              )}
              
              {!state.readOnly && (
                <>
                  <button
                    onClick={() => handleSave(false)}
                    disabled={saving || !state.isDirty}
                    className="flex items-center px-4 py-2 space-x-2 text-gray-700 transition-colors bg-white border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <Save className="w-4 h-4" />
                    <span>{saving ? 'กำลังบันทึก...' : 'บันทึก'}</span>
                  </button>
                  
                  <button
                    onClick={handleSubmit}
                    disabled={submitting || scoreCalculation.completedQuestions === 0}
                    className="flex items-center px-6 py-2 space-x-2 text-white transition-all duration-200 rounded-lg shadow-md bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 disabled:opacity-50 disabled:cursor-not-allowed hover:shadow-lg"
                  >
                    <Send className="w-4 h-4" />
                    <span>{submitting ? 'กำลังส่ง...' : 'ส่งการประเมิน'}</span>
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="px-6 py-6 mx-auto max-w-7xl">
        <div className="space-y-6">
          {/* Vendor Information */}
          {renderVendorInfo()}

          {/* Auditor Information */}
          {renderAuditorSection()}

          {/* Summary Section */}
          {renderSummarySection()}

          {/* Questions Section */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="flex items-center text-xl font-semibold text-gray-900">
                <FileText className="w-6 h-6 mr-2 text-blue-600" />
                แบบประเมิน CSM
              </h2>
              <div className="flex items-center space-x-3">
                <span className="text-sm text-gray-500">
                  {scoreCalculation.completedQuestions}/{scoreCalculation.totalQuestions} ข้อเสร็จสิ้น
                </span>
                <div className="w-24 h-2 bg-gray-200 rounded-full">
                  <div 
                    className="h-2 transition-all duration-500 rounded-full bg-gradient-to-r from-blue-500 to-green-500"
                    style={{ 
                      width: `${(scoreCalculation.completedQuestions / scoreCalculation.totalQuestions) * 100}%` 
                    }}
                  />
                </div>
              </div>
            </div>

            {renderQuestionsSection()}
          </div>
        </div>
      </div>

      {/* Loading Overlay */}
      {(saving || submitting) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
          <div className="p-6 bg-white shadow-2xl rounded-xl">
            <div className="flex items-center space-x-4">
              <div className="w-8 h-8 border-4 border-blue-600 rounded-full border-t-transparent animate-spin"></div>
              <span className="text-lg font-medium text-gray-900">
                {saving ? 'กำลังบันทึกข้อมูล...' : 'กำลังส่งการประเมิน...'}
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CSMEvaluatePage;